import time
time.sleep(0)

from emood import *

main()